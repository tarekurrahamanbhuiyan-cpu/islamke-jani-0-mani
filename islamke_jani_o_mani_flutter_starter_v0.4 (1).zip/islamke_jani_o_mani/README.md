# ইসলামকে জানি ও মানি — Flutter starter v0.4.0

বাংলা ভাষায় বিষয়ভিত্তিক ইসলামি শিক্ষার Android অ্যাপের প্রাথমিক, চালানোযোগ্য Flutter সোর্স প্রজেক্ট।

## অন্তর্ভুক্ত
- ২০টি ইসলামি বিষয়ভিত্তিক বিভাগ
- প্রতিটি বিভাগে কুরআনের নির্বাচিত রেফারেন্স, বাংলা সারমর্ম, হাদিসের নির্বাচিত রেফারেন্স/সারাংশ, আলোচনা ও করণীয়
- বিষয় অনুসন্ধান
- SharedPreferences দিয়ে ডিভাইসে সংরক্ষিত বিষয় (বুকমার্ক)
- কুরআন রেফারেন্স ও হাদিসের আলাদা তালিকা
- GitHub Actions workflow দিয়ে Android release APK বিল্ডের ব্যবস্থা

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনও সম্পূর্ণ কুরআন/হাদিসের ডাটাবেস নয় এবং APK এই পরিবেশে বিল্ড/পরীক্ষা করা হয়নি। কিছু কনটেন্টে আরবি মূল পাঠ নেই; বাংলা অংশগুলো সংক্ষিপ্ত সারমর্ম। প্রকাশের আগে সব আয়াত, অনুবাদ, হাদিস নম্বর/মান, ফিকহি ব্যাখ্যা এবং কপিরাইট/লাইসেন্স যাচাই করতে হবে। হাদিসের রেফারেন্স নম্বর বিভিন্ন সংস্করণে ভিন্ন হতে পারে। এটি ব্যক্তিগত ধর্মীয় ফতোয়ার বিকল্প নয়।

## লোকাল বিল্ড
Flutter SDK 3.3+ সমর্থিত Dart সংস্করণসহ ইনস্টল করে:

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

APK পাওয়া যাবে `build/app/outputs/flutter-apk/app-release.apk`-এ।

## GitHub থেকে APK বিল্ড
1. এই ফোল্ডারের ফাইলগুলো GitHub repository-র root-এ আপলোড করুন।
2. `main` branch-এ push করুন অথবা GitHub-এর Actions ট্যাবে `Build Android APK` চালান।
3. সফল workflow run খুলে `islamke-jani-o-mani-apk` artifact ডাউনলোড করুন।

## সম্পূর্ণ কুরআন ডেটা যোগ করা
Quran Foundation Content API ব্যবহার করতে হলে তাদের Developer Console-এ অ্যাপ নিবন্ধন, production access/অনুমোদন, সঠিক attribution এবং API terms মেনে চলতে হবে। `client_secret` কখনো Android অ্যাপের ভেতরে রাখবেন না; নিরাপদ backend-এ রাখুন। অফলাইন কনটেন্টের জন্য অনুমোদিত Content Sync পদ্ধতি অনুসরণ করুন।

সূত্র: https://api-docs.quran.foundation/docs/quickstart/ এবং https://api-docs.quran.foundation/docs/tutorials/content-sync/getting-started/
